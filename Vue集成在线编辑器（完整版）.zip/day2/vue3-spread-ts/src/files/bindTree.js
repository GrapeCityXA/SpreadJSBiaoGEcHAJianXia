 export var bindSchema = { "$schema": "http://json-schema.org/draft-04/schema#", "properties": { "grade": { "dataFieldType": "text", "type": "string" }, "class": { "dataFieldType": "text", "type": "string" }, "headmaster": { "dataFieldType": "text", "type": "string" }, "reports": { "dataFieldType": "table", "type": "array", "items": { "type": "object", "properties": { "name": { "type": "string" }, "age": { "type": "string" }, "math": { "type": "string" }, "english": { "type": "string" }, "chinese": { "type": "string" }, "sports": { "type": "string" } } } } }, "type": "object" }

 export const generateData = (count) => {
    let reportList = []
    for(let i=0; i<count;i++){
        reportList.push({
            name:'' + '2022',
            age:Math.floor(Math.random() * 6 + 7),
            math: Math.round((Math.random()*50 + 50)),
            chinese: Math.round((Math.random()*50 + 50)),
            english: Math.round((Math.random()*50 + 50)),
            sports: Math.round((Math.random()*50 + 50)),
        })
    }
    let data = {
        grade: '苹果',
        class: '一斤',
        headmaster: '葡萄城',
        reports:reportList
    }
    return data
 }
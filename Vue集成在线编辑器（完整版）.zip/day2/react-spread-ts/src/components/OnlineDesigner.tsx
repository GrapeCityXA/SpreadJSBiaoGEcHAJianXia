import "@grapecity/spread-sheets-designer/styles/gc.spread.sheets.designer.min.css"
import "@grapecity/spread-sheets/styles/gc.spread.sheets.excel2013lightGray.css"
import "@grapecity/spread-sheets-barcode"
import "@grapecity/spread-sheets-charts"
// 框架中excelIO需要授权
import * as ExcelIO from "@grapecity/spread-excelio"
// 引入中文资源，也可以使用日文或韩文，按照自己的需求安装不同语言资源并引入即可
import '@grapecity/spread-sheets-resources-zh'
import "@grapecity/spread-sheets-shapes"
import "@grapecity/spread-sheets-pivot-addon"
import "@grapecity/spread-sheets-print"
import "@grapecity/spread-sheets-pdf"
import GC from "@grapecity/spread-sheets"
import "@grapecity/spread-sheets-designer-resources-cn"
import {Designer} from  "@grapecity/spread-sheets-designer-react"
import * as GcDesigner from "@grapecity/spread-sheets-designer"
GC.Spread.Common.CultureManager.culture('zh-cn')

export default function OnlineDesigner(){

    let designer:GcDesigner.Spread.Sheets.Designer.Designer|null = null
    let workbook:GC.Spread.Sheets.Workbook|null = null
    
    const initDesigner = (designerEntity:GcDesigner.Spread.Sheets.Designer.Designer) => {
        designer = designerEntity
        let spread = designer.getWorkbook() as GC.Spread.Sheets.Workbook
        let sheet:GC.Spread.Sheets.Worksheet = spread.getActiveSheet()
        sheet.setValue(0,0,'grapeCity')
    }
    
    return(
        <Designer styleInfo={{height:'97vh'}} designerInitialized={initDesigner}></Designer>
    )
  
}
import { useState } from 'react'
import OnlineSpread from './components/OnlineSpread'
import OnlineDesigner from './components/OnlineDesigner'


function App() {
  return (
    <div className="App">
       <OnlineDesigner/>
    </div>
  )
}

export default App

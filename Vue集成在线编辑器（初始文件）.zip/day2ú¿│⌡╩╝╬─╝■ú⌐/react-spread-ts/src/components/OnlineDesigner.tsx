

export default function OnlineDesigner(){
 
    return(
        <div>React Designer</div>
    )
}
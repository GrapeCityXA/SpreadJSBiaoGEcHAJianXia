<script setup lang="ts">
  import onlineSpread from './components/OnlineSpread.vue'
  import onlineDesigner from './components/OnlineDesigner.vue'
import OnlineDesigner from './components/OnlineDesigner.vue'
</script>

<template>
  <online-designer/>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center;
  color: #2c3e50;
  margin-top: 60px; */
}
</style>

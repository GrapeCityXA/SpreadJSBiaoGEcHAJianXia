<script>
import { defineComponent } from "vue";
// spreadjs组件运行时资源
import * as GC from "@grapecity/spread-sheets";
//引入Vue支持组件
import { GcSpreadSheets, GcWorksheet } from "@grapecity/spread-sheets-vue";
//引入符合自己项目主题的样式
import "@grapecity/spread-sheets/styles/gc.spread.sheets.excel2013white.css";
// 引入导入导出文件相关的资源
import * as ExcelIO from "@grapecity/spread-excelio";
// 打印资源
import "@grapecity/spread-sheets-print"
// 导出pdf资源
import "@grapecity/spread-sheets-pdf"
//设置中文
import "@grapecity/spread-sheets-resources-zh";
import { saveAs } from "file-saver";
GC.Spread.Common.CultureManager.culture("zh-cn");
export default defineComponent({
  components: {
    "gc-spread-sheets": GcSpreadSheets,
  },
  setup() {
    const hostStyle = {
      height: "90vh",
    };
    let spread = null;
    const initWorkbook = (spreadEntity) => {
      spread = spreadEntity;
      // customMenu(spread)           //专题一:自定义右键菜单
      let sheet = spread.getActiveSheet();
      sheet.setValue(0, 0, "grapecity");
    };
    const importFile = (file) => {
      let io = new ExcelIO.IO();
      // excelio打开文件，回调函数中的参数时spreadjs支持的json格式
      io.open(file, (fileJSON) => {
        // fromJSON中第二个参数为导入文件的控制参数，默认均为false,根据自己的需求添加,都不要修改时可不传
        spread.fromJSON(fileJSON, {
          ignoreFormula: false, //导入忽略公式
          ignoreStyle: false, //导入忽略样式
          frozenColumnsAsRowHeaders: false, //将冻结列当作行头
          frozenRowsAsColumnHeaders: false, //将冻结行作为列头
          // 导入文件不立即计算. Excel文件保存时会自动计算,当文件比较大时,可以导入后不计算,提高导入效率.
          doNotRecalculateAfterLoad: false,
        });
      });
      return false;
    };
    const downloadFile = () => {
      let fileJSON = spread.toJSON();
      let io = new ExcelIO.IO();
      io.save(
        fileJSON,
        (blob) => {
          saveAs(blob, "导出文件.xlsx");
        },
        () => {}
      );
    };
    // 自定义右键菜单
    const customMenu = (spread) => {
      // 设置右键菜单第一项不可用（置灰）
      spread.contextMenu.menuData[0].disable = true;
      // 删除右键菜单第一项
      spread.contextMenu.menuData.splice(0, 1);
      // 获取当前spread的命令管理器
      let commandManager = spread.commandManager();
      // 定义右键菜单项
      let markWithRedBg = {
        text: "Format Cells",
        name: "markWithRedBg",
        command: "markWithRedBg",
        workArea: "viewport",
      };
      // 将定义好的右键菜单项push到menuData当中
      spread.contextMenu.menuData.push(markWithRedBg);
      // 定义命令的实际执行体
      let markWithRedBgCommand = {
        canUndo: false,
        execute: function () {
          //新建样式
          let style = new GC.Spread.Sheets.Style();
          // 定义样式名称
          style.name = "style1";
          //定义背景色
          style.backColor = "red";
          let sheet = spread.getActiveSheet();
          // 性能优化-暂停绘制
          sheet.suspendPaint();
          // 获取当前选中区域，可多选
          let selections = sheet.getSelections();
          let selectionIndex = 0,
            selectionCount = selections.length;
          for (; selectionIndex < selectionCount; selectionIndex++) {
            let selection = selections[selectionIndex];
            for (
              let i = selection.row;
              i < selection.row + selection.rowCount;
              i++
            ) {
              for (
                let j = selection.col;
                j < selection.col + selection.colCount;
                j++
              ) {
                sheet.setStyle(
                  i,
                  j,
                  style,
                  GC.Spread.Sheets.SheetArea.viewport
                );
              }
            }
          }
          // 恢复绘制
          sheet.resumePaint();
        },
      };
      commandManager.register(
        "markWithRedBg",
        markWithRedBgCommand,
        null,
        false,
        false,
        false,
        false
      );
    };

    const printFile = () => {
      // 打印
        let printInfo = new GC.Spread.Sheets.Print.PrintInfo()
        printInfo.showRowHeader(false)
        printInfo.showColumnHeader(false)
        printInfo.fitPagesWide(1)
        let sheet = spread.getActiveSheet()
        sheet.printInfo(printInfo)
        spread.print()
    }

   //导出PDF
    const exportPDF = () => {
    printFile()
      spread.savePDF((blob)=>{
        saveAs(blob,'导出.pdf')
      },(e)=>{
        console.log(e)
      },{
          title: "Test Title",
          author: "Test Author",
          subject: "Test Subject",
          keywords: "Test Keywords",
          creator: "test Creator",
        }
      )
    }
    return {
      hostStyle,
      initWorkbook,
      importFile,
      downloadFile,
      printFile,
      exportPDF
    };
  },
});
</script>

<template>
  <div>
    <el-upload
      class="upload-demo"
      accept=".xlsx"
      :before-upload="importFile"
      action=""
    >
      <el-button type="primary">上传文件</el-button>
    </el-upload>
    <el-button type="primary" @click="downloadFile">下载文件</el-button>
    <el-button type="primary" @click="printFile">打印</el-button>
    <el-button type="primary" @click="exportPDF">导出PDF</el-button>
    <gc-spread-sheets
      :hostStyle="hostStyle"
      @workbookInitialized="initWorkbook"
    ></gc-spread-sheets>
  </div>
</template>

<style>
.upload-demo {
  display: inline-block;
  margin-right: 8px;
}
</style>
import axios from "axios"
import {ElLoading,ElNotification} from 'element-plus' 
import { resolveComponent } from "vue"

const instance = axios.create({
    baseURL:"http://localhost:8088",
    timeout: 10000,
    headers:{
        'Access-Control-Allow-Origin':"*",
        'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept',
    }
})

export default class HttpUtils {
    public static get(url: string){
        return new Promise((resolve,reject) => {
            let loadingEnstance = ElLoading.service({fullscreen: true})
            instance.get(url)
            .then(response=>{resolve(response.data)})
            .catch((err) => {
                ElNotification({title:'错误',message: err,type:'error'})
                resolve(undefined)
            })
            .finally(
                () => {loadingEnstance.close()}
            )
        })
    }

    public static post(url: string,params:any={},config:any = {}){
        return new Promise((resolve,reject) => {
            let loadingEnstance = ElLoading.service({fullscreen: true})
            instance.post(url,params,config)
            .then(response => {resolve(response.data)})
            .catch((err) => {
                ElNotification({title:'错误',message: err,type:'error'})
                resolve(undefined)
            })
            .finally(() => {loadingEnstance.close()})
        })
    }
}